import React from 'react'
import { Container } from 'react-bootstrap'
import { IoSearchSharp } from "react-icons/io5";
import './Header.css'
import Button from 'react-bootstrap/Button';
import { CiSearch } from "react-icons/ci";

const Header = () => {
  return (
    <div>
      <Container>
    <div>
        <div>
            <div className='subnav'>Search Among <span className='subcontent'>58340</span> Courses And<br />Find Your Favorite Course</div>
        </div>
        {/* <div className='navcontent'>
            <div className='nav'><span className='navigation'>Categories</span><span className='box'>Search Anything</span><IoSearchSharp  className='sharp'/></div>
        </div> */}
           <Button variant="light">
           <Button variant="dark">Categories</Button>
           <span className='dark-12-3'>Search Anything</span>
           <CiSearch  className='light-32-23'/>
           
           </Button>



    </div>
    </Container>
        

    </div>
  )
}

export default Header
