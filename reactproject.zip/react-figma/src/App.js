
// import './App.css';

// import Home from './Home/Home';
 
// function App() {
//   return (
//     <div className="App">
// <Home/>
//     </div>
//   );
// }

// export default App;
import React from 'react';
import Home from './Home/Home'; 
import Navbar from './Navbar/Navbar';
import Header from './Header/Header';
import Addcard from './Addcard/Addcard';
import Addtofile from './Addtofile/Addtofile'
import Subcardfunction from './Subcardfunction/Subcardfunction';
import Filecard from './Filecard/Filecard';
import Addfilecard from './Addfilecard/Addfilecard'
import Subnavbar from './Subnavbar/Subnavbar'
import Footer from './Footer/Footer';




const App = () => {
  return (
    <div>
        <Home />  
       <Subnavbar />
       <Navbar />
      <Header /><br /><br />
      <Addcard /><br /><br />
      <Addtofile /> <br /><br /><br /><br /><br /> 
      <Subcardfunction /><br /><br />
      <Filecard /><br /> 
      <Addfilecard /> <br /><br /><br /><br /><br />
      <Addtofile /><br /><br />
      <Footer />
      
    </div>
  );
};

export default App;
