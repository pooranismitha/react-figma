import React from 'react'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Newtest from '../Images/Grop 12.png'

const Newsletter = () => {
  return (
    <Row>
    <Col>
    <img src={Newtest} alt='text'></img>
    
    
    </Col>
  </Row>
  )
}

export default Newsletter